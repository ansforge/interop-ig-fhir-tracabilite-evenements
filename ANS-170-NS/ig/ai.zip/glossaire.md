# Glossaire - ANS - Traçabilité des événements v2.0.0

* [**Table of Contents**](toc.md)
* [**Historique des versions**](change-log.md)
* **Glossaire**

## Glossaire

| Sigle / Acronyme | Signification | |—-|—-| | ASIP Santé | Agence Française de la Santé Numérique | | HL7 | **Health Level 7** | | FHIR | **Fast Healthcare Interoperability Ressources** | | CI-SIS | Cadre d’interopérabilité des systèmes d’information de santé | | DICOM | Digital Imaging and COmmunication in Medecine | | GS1 | Global Standards 1 |


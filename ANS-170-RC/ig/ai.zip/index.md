# Accueil - ANS - Traçabilité des événements v2.0.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tde/ImplementationGuide/ans.fhir.fr.tde | *Version*:2.0.0 |
| Draft as of 2026-01-21 | *Computable Name*:TDE |

 **Brief description of this Implementation Guide**
 [Add a brief description of this IG in English] 

> Cet Implementation Guide n'est pas la version courante, il s'agit de la version en intégration continue soumise à des changements fréquents uniquement destinée à suivre les travaux en cours. La version courante sera accessible via l'URL canonique suite à la première release : http://interop.esante.gouv.fr/ig/fhir/[code - ig]

### Introduction

Ce guide d'implémentation présente une spécification générique des échanges pour la gestion des traces.

Les traces sont l’ensemble des informations enregistrées relatant les actions entreprises par un système en conséquence d’un événement. Les informations peuvent aussi bien porter sur des dispositifs physiques, comme par exemple un dispositif médical implantable (changement de lieu, mise à jour du statut), que sur des actions utilisateurs (connexion à un système, création d'un utilisateur). Dans le cadre de cette étude, les processus qui sont à l'origine des traces sont hors périmètre.

### Périmètre du projet

Définir en quelques lignes en anglais quel est le périmètre du projet

Toujours laisser l'onglet "Ressources de conformité" pour s'assurer d'une cohérence globales entre tous les IGs

#### Lectorat cible

Les lecteurs cibles sont principalement des chefs de projets ainsi que toute personne concernée par la maitrise d’ouvrage et qui spécifie des projets avec des interfaces interopérables.

### Standards utilisés

Les données véhiculées dans ce volet ainsi que les interactions entre les systèmes reposent sur le standard HL7 FHIR Release 4.

Les interactions font référence à un certain nombre de ressources du standard ainsi qu’aux spécifications de l’API REST FHIR, basées sur le protocole HTTP dans sa version sécurisée HTTPS. Les syntaxes retenues sont la syntaxe XML et JSON.

#### Ressources FHIR profilées

Les ressources profilées dans le cadre de ce guide d'implémentation sont les suivantes :

| | | |
| :--- | :--- | :--- |
| Profil parent | Profil | Description |
| [AuditEvent](http://hl7.org/fhir/StructureDefinition/AuditEvent) | [TDEAuditEvent](StructureDefinition-TDEAuditEvent.md) | Profil représentant la trace d'un évènement |
| [Bundle](http://hl7.org/fhir/StructureDefinition/Bundle) | [TDEBundleResultatReponseRechercheTraces](StructureDefinition-TDEBundleResultatReponseRechercheTraces.md) | Bundle de réponse à la recherche de traces |

### Dépendances





### Propriété intellectuelle

Certaines ressources sémantiques de ce guide sont protégées par des droits de propriété intellectuelle couverte par les déclarations ci-dessous. L’utilisation de ces ressources est soumise à l’acceptation et au respect des conditions précisées dans la licence d’utilisation de chacune d’entre elle.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.0.2/CodeSystem-ISO3166Part1.html): [TDE](index.md), [TDEAuditEvent](StructureDefinition-TDEAuditEvent.md)... Show 5 more, [TDEBundleResultatReponseRechercheTraces](StructureDefinition-TDEBundleResultatReponseRechercheTraces.md), [TDE_AuditEvent_period-start](SearchParameter-TDE-AuditEvent-period-start.md), [TdEConsommateur](CapabilityStatement-TdEConsommateur.md), [TdEGestionnaire](CapabilityStatement-TdEGestionnaire.md) and [TdESource](CapabilityStatement-TdESource.md)


* These codes are excerpted from Digital Imaging and Communications in Medicine (DICOM) Standard, Part 16: Content Mapping Resource, Copyright © 2011 by the National Electrical Manufacturers Association.

* [Audit Event ID](http://terminology.hl7.org/7.0.1/CodeSystem-audit-event-type.html): [AuditEvent/TDEAuditEventExample](AuditEvent-TDEAuditEventExample.md) and [Bundle/TDEBundleResultatReponseRechercheTracesExample](Bundle-TDEBundleResultatReponseRechercheTracesExample.md)



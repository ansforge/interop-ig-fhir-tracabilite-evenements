# ans.fhir.fr.tde#2.0.0: ANS - Traçabilité des événements(en)

## Pages

* [Accueil](index.md)
* [Téléchargements et usages](downloads.md)
* [Etude norme et standards](normes_standards.md)
* [Artifacts Summary](artifacts.md)
* [Sécurité](securite.md)
* [Correspondances métier](specifications_technique_correspondance_metier.md)
* [Via syslog](specifications_technique_syslog.md)
* [Via API REST](specifications_technique_api.md)
* [Volume 1 - Etude fonctionnelle](specifications_fonctionnelles.md)
* [Volume 2 - Détail des transactions](specifications_technique_intro.md)
* [Historique des versions](change-log.md)
* [Glossaire](glossaire.md)
* [Mise en correspondance AuditEvent / DICOM](annexe_audit_dicom.md)

## Resources

### Resource Profiles

* [TDEBundleResultatReponseRechercheTraces](StructureDefinition-TDEBundleResultatReponseRechercheTraces.md)
* [TdE AuditEvent](StructureDefinition-tde-auditevent.md)

### CapabilityStatements

* [TdE-Consommateur](CapabilityStatement-TdEConsommateur.md)
* [TdE-Gestionnaire](CapabilityStatement-TdEGestionnaire.md)
* [TdE-Source](CapabilityStatement-TdESource.md)

### ImplementationGuides

* [ANS - Traçabilité des événements](ImplementationGuide-ans.fhir.fr.tde.md)

### SearchParameters

* [TDE_AuditEvent_period-start](SearchParameter-TDE-AuditEvent-period-start.md)

### Examples

* [TDEAuditEventExample-2 (AuditEvent)](AuditEvent-TDEAuditEventExample-2.md)
* [TDEAuditEventExample (AuditEvent)](AuditEvent-TDEAuditEventExample.md)
* [TDEBundleResultatReponseRechercheTracesExample (Bundle)](Bundle-TDEBundleResultatReponseRechercheTracesExample.md)
* [DeviceExample (Device)](Device-DeviceExample.md)
* [PractitionerExample (Practitioner)](Practitioner-PractitionerExample.md)
